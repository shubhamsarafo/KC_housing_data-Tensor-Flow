#loveseat_Description

lovely_loveseat_description = """Lovely Loveseat.Tutfted polyester blend on wood. 32 inches high x 40 inches wide x 30 inches deep. Red or White. \n"""

#loveseat_price

lovely_loveseat_price = 254.00

#settee_description

stylish_settee_description = """Stylish settee. 
Faux leather on birch. 29.50 inches high x 54.75
inches wide x 28 inches deep. Black. \n """

#settee_price

stylish_Settee_price = 180.50

#lamp_description

luxurious_lamp_description = """Luxurious Lamp.
Glass and iron.36 inches tall.Brown with cream shade. \n"""

#lamp_price

luxurious_lamp_price = 52.15


#salestax_value

sales_tax = .088

#customer_Ref

customer_one_total = 0
customer_one_itemization = ""

customer_one_total += lovely_loveseat_price
customer_one_itemization += lovely_loveseat_description

customer_one_total +=luxurious_lamp_price
customer_one_itemization +=luxurious_lamp_description


#customer_tax

customer_one_tax = customer_one_total * sales_tax

customer_one_total += customer_one_tax

print("customer one items:")
print(customer_one_itemization)


print("customer one total")
print(customer_one_total)








